package grails.plugin.jesque

enum JesqueScheduleThreadState {
    New,
    Running,
    Stopped
}
