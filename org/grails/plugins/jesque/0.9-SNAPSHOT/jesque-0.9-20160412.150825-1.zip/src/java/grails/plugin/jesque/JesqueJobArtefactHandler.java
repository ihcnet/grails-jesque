package grails.plugin.jesque;

import org.codehaus.groovy.grails.commons.ArtefactHandlerAdapter;

public class JesqueJobArtefactHandler extends ArtefactHandlerAdapter {

    public static final String TYPE = "JesqueJob";

    public JesqueJobArtefactHandler() {
        super(TYPE, GrailsJesqueJobClass.class, DefaultGrailsJesqueJobClass.class, null);
    }

    public boolean isArtefactClass(Class clazz) {
        // class shouldn't be null and should end with Job suffix
        return !(clazz == null || !clazz.getName().endsWith(DefaultGrailsJesqueJobClass.JOB)) && Runnable.class.isAssignableFrom(clazz);
    }
}
